package com.vilius.turbobroccoli.dao;

import java.io.Serializable;

public interface UserFileRepository extends Serializable {
}
