package com.vilius.shinybroccoli.model;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "ADDRESS")
@Getter @Setter @NoArgsConstructor
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "ID", unique = true, updatable = false, nullable = false)
    @Setter(AccessLevel.NONE)
    private Long id;
    @Column(name = "HOUSE_NUMBER")
    private String houseNumber;
    @Column(name = "STREET")
    private String street;
    @Column(name = "COUNTRY")
    private String country;
}
