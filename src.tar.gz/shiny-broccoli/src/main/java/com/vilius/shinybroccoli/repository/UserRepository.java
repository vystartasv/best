package com.vilius.shinybroccoli.repository;

import com.vilius.shinybroccoli.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long>{
}
