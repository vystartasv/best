package com.vilius.shinybroccoli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShinyBroccoliApplication {

    public static void main(String[] args) {
        SpringApplication.run(ShinyBroccoliApplication.class, args);
    }
}
