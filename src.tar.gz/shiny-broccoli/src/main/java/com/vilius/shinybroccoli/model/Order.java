package com.vilius.shinybroccoli.model;

public class Order {
}
