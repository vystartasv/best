package com.vilius.laughingoctopotato.repository;

import com.vilius.laughingoctopotato.model.User;

import java.util.List;

public interface UserRepository {
    long save(User user);
    User get(long id);
    List<User> list();
    void update(long id, User user);
    void delete(long id);
}
