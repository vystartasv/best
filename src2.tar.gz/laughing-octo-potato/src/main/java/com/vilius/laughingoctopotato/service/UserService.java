package com.vilius.laughingoctopotato.service;

public interface UserService {
}
