package com.vilius.laughingoctopotato.controller;

public class UserController {
}
