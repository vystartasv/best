package com.vilius.laughingoctopotato.service;

public class UserServiceImpl {
}
