package com.vilius.laughingoctopotato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaughingOctoPotatoApplication {

    public static void main(String[] args) {
        SpringApplication.run(LaughingOctoPotatoApplication.class, args);
    }
}
